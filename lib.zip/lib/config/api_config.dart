// lib/config/api_config.dart

class ApiConfig {
  // ── Base URL ───────────────────────────────────────────────────────
  // 10.0.2.2 is Android emulator's alias for your PC's localhost
  static const String baseUrl = 'http://192.168.100.8:8000/api';

  // ── Auth ───────────────────────────────────────────────────────────
  static const String login    = '/login';
  static const String register = '/register';
  static const String logout   = '/logout';
  static const String user     = '/user';

  // ── Photographers ──────────────────────────────────────────────────
  static const String photographers = '/photographers';
  static const String dashboard     = '/photographer/dashboard';
  static const String profile       = '/photographer/profile';
  static const String portfolio     = '/photographer/portfolio';

  // ── Bookings ───────────────────────────────────────────────────────
  static const String bookings = '/bookings';

  // ── Messages ───────────────────────────────────────────────────────
  static const String messages      = '/messages';
  static const String conversations = '/messages/conversations';
  static const String unreadCount   = '/messages/unread-count';

  // ── Ratings & Reviews ──────────────────────────────────────────────
  static const String ratings = '/ratings';

  // ── Subscriptions ──────────────────────────────────────────────────
  static const String subscriptions        = '/subscriptions';
  static const String subscriptionPlans    = '/subscriptions/plans';
  static const String subscriptionCurrent  = '/subscriptions/current';
  static const String subscriptionHistory  = '/subscriptions/history';
  static const String subscriptionSubscribe = '/subscriptions/subscribe';

  // ── Payments ───────────────────────────────────────────────────────
  static const String payments         = '/payments';
  static const String paymentsInitiate = '/payments/initiate';

  // ── Admin ──────────────────────────────────────────────────────────
  static const String adminStats         = '/admin/stats';
  static const String adminPhotographers = '/admin/photographers';
  static const String adminClients       = '/admin/clients';
  static const String adminReports       = '/admin/reports';
  static const String adminLocations     = '/admin/locations';
  static const String adminCategories    = '/admin/categories';
  static const String adminPayments      = '/admin/payments';
}
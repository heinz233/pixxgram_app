// lib/services/admin_service.dart

import 'api_service.dart';
import '../config/api_config.dart';


class AdminService {
  static Future<Map<String, dynamic>> getStats() async {
    final res = await ApiService.get(ApiConfig.adminStats);
    return res.data;
  }

  static Future<Map<String, dynamic>> getPhotographers({String? status}) async {
    final res = await ApiService.get(ApiConfig.adminPhotographers,
        params: status != null ? {'status': status} : null);
    return res.data;
  }

  static Future<void> approvePhotographer(int id) async {
    await ApiService.patch('${ApiConfig.adminPhotographers}/$id/approve');
  }

  static Future<void> suspendPhotographer(int id) async {
    await ApiService.patch('${ApiConfig.adminPhotographers}/$id/suspend');
  }

  static Future<Map<String, dynamic>> getReports({String? status}) async {
    final res = await ApiService.get(ApiConfig.adminReports,
        params: status != null ? {'status': status} : null);
    return res.data;
  }

  static Future<void> resolveReport(int id) async {
    await ApiService.patch('${ApiConfig.adminReports}/$id/resolve');
  }

  static Future<void> dismissReport(int id) async {
    await ApiService.patch('${ApiConfig.adminReports}/$id/dismiss');
  }

  static Future<dynamic> getLocations() async {
    final res = await ApiService.get(ApiConfig.adminLocations);
    return res.data;
  }

  static Future<Map<String, dynamic>> createLocation(String name,
      {String? region}) async {
    final res = await ApiService.post(ApiConfig.adminLocations,
        data: {'name': name, if (region != null) 'region': region});
    return res.data;
  }

  static Future<void> updateLocation(int id, String name,
      {String? region}) async {
    await ApiService.put('${ApiConfig.adminLocations}/$id',
        data: {'name': name, if (region != null) 'region': region});
  }

  static Future<void> deleteLocation(int id) async {
    await ApiService.delete('${ApiConfig.adminLocations}/$id');
  }

  static Future<dynamic> getCategories() async {
    final res = await ApiService.get(ApiConfig.adminCategories);
    return res.data;
  }

  static Future<Map<String, dynamic>> createCategory(String name,
      {String? description}) async {
    final res = await ApiService.post(ApiConfig.adminCategories,
        data: {'name': name, if (description != null) 'description': description});
    return res.data;
  }

  static Future<void> deleteCategory(int id) async {
    await ApiService.delete('${ApiConfig.adminCategories}/$id');
  }

  static Future<Map<String, dynamic>> getPayments() async {
    final res = await ApiService.get(ApiConfig.adminPayments);
    return res.data;
  }

  static Future<Map<String, dynamic>> getClients() async {
    final res = await ApiService.get(ApiConfig.adminClients);
    return res.data;
  }
}
// lib/services/booking_service.dart

import 'api_service.dart';
import '../config/api_config.dart';

class BookingService {
  // ── Get all bookings for the authenticated user ────────────────────
  static Future<Map<String, dynamic>> getAll() async {
    final res = await ApiService.get(ApiConfig.bookings);
    return res.data;
  }

  // ── Get a single booking by ID ─────────────────────────────────────
  static Future<Map<String, dynamic>> getOne(int id) async {
    final res = await ApiService.get('${ApiConfig.bookings}/$id');
    return res.data;
  }

  // ── Create a new booking (client) ──────────────────────────────────
  static Future<Map<String, dynamic>> create({
    required int photographerId,
    required String bookingDate,
    String? notes,
  }) async {
    final res = await ApiService.post(ApiConfig.bookings, data: {
      'photographer_id': photographerId,
      'booking_date':    bookingDate,
      if (notes != null) 'notes': notes,
    });
    return res.data;
  }

  // ── Update booking status (photographer: confirm/complete, client: cancel) ─
  static Future<Map<String, dynamic>> updateStatus(int id, String status) async {
    final res = await ApiService.patch(
      '${ApiConfig.bookings}/$id/status',
      data: {'status': status},
    );
    return res.data;
  }

  // ── Cancel a booking (client shorthand) ───────────────────────────
  static Future<Map<String, dynamic>> cancel(int id) async {
    return updateStatus(id, 'cancelled');
  }

  // ── Get bookings for photographer dashboard ────────────────────────
  static Future<Map<String, dynamic>> getPhotographerBookings({
    String? status,
  }) async {
    final res = await ApiService.get(
      '${ApiConfig.bookings}/photographer',
      params: status != null ? {'status': status} : null,
    );
    return res.data;
  }
}
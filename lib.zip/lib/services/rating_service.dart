// lib/services/rating_service.dart
import 'api_service.dart';
import '../config/api_config.dart';

class RatingService {
  static Future<Map<String, dynamic>> submit(int photographerId, int stars,
      {String? comment}) async {
    final res = await ApiService.post('${ApiConfig.ratings}/$photographerId',
        data: {'stars': stars, if (comment != null) 'comment': comment});
    return res.data;
  }

  static Future<dynamic> getForPhotographer(int photographerId) async {
    final res = await ApiService.get('${ApiConfig.ratings}/photographer/$photographerId');
    return res.data['reviews'] ?? res.data;
  }

  static Future<void> remove(int id) async {
    await ApiService.delete('${ApiConfig.ratings}/$id');
  }
}
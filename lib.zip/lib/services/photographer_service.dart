// lib/services/photographer_service.dart

import 'package:dio/dio.dart';
import 'api_service.dart';
import '../config/api_config.dart';

class PhotographerService {
  // ── Public: list all active photographers ────────────────────────────────
  static Future<Map<String, dynamic>> getAll({
    Map<String, dynamic>? filters,
  }) async {
    try {
      final res = await ApiService.get(
        ApiConfig.photographers,
        params: filters,
      );
      // Handle both paginated and non-paginated responses
      final data = res.data;
      if (data is Map) {
        // If the response has a data key inside photographers
        if (data['photographers'] is Map &&
            data['photographers']['data'] != null) {
          return Map<String, dynamic>.from(data)..['photographers'] = data['photographers']['data'];
        }
        // If photographers is directly a list
        if (data['photographers'] is List) {
          return Map<String, dynamic>.from(data)..['photographers'] = data['photographers'];
        }
        // If the response IS the list directly
        if (data['data'] is List) {
          return {'photographers': data};
        }
      }
      return data;
    } on DioException catch (e) {
      print('PhotographerService.getAll error: ${e.message}');
      print('Status: ${e.response?.statusCode}');
      print('Response: ${e.response?.data}');
      rethrow;
    }
  }

  // ── Public: single photographer profile + portfolio + reviews ────────────
  static Future<Map<String, dynamic>> getById(int id) async {
    try {
      print('Fetching photographer ID: $id');
      final res = await ApiService.get('${ApiConfig.photographers}/$id');
      final data = res.data as Map<String, dynamic>;
      print('Photographer response keys: ${data.keys.toList()}');

      // Normalise — some APIs wrap in 'data', some don't
      Map<String, dynamic> photographer;
      List portfolio;
      List reviews;

      if (data['photographer'] != null) {
        photographer = data['photographer'] as Map<String, dynamic>;
      } else if (data['data'] != null) {
        photographer = data['data'] as Map<String, dynamic>;
      } else {
        // The whole response might be the photographer object
        photographer = data;
      }

      portfolio = data['portfolio'] as List? ?? [];
      reviews   = data['reviews']   as List? ?? [];

      return {
        'photographer': photographer,
        'portfolio':    portfolio,
        'reviews':      reviews,
      };
    } on DioException catch (e) {
      print('PhotographerService.getById($id) error: ${e.message}');
      print('Status: ${e.response?.statusCode}');
      print('Response: ${e.response?.data}');
      rethrow;
    }
  }

  // ── Authenticated: own dashboard stats ───────────────────────────────────
  static Future<Map<String, dynamic>> getDashboard() async {
    try {
      final res = await ApiService.get(ApiConfig.dashboard);
      return res.data as Map<String, dynamic>;
    } on DioException catch (e) {
      print('PhotographerService.getDashboard error: ${e.message}');
      print('Status: ${e.response?.statusCode}');
      rethrow;
    }
  }

  // ── Authenticated: update own profile ────────────────────────────────────
  static Future<Map<String, dynamic>> updateProfile(FormData data) async {
    try {
      final res = await ApiService.upload(ApiConfig.profile, data);
      return res.data as Map<String, dynamic>;
    } on DioException catch (e) {
      print('PhotographerService.updateProfile error: ${e.message}');
      rethrow;
    }
  }

  // ── Authenticated: upload portfolio images ───────────────────────────────
  static Future<Map<String, dynamic>> uploadPortfolio(FormData data) async {
    try {
      final res = await ApiService.upload(ApiConfig.portfolio, data);
      return res.data as Map<String, dynamic>;
    } on DioException catch (e) {
      print('PhotographerService.uploadPortfolio error: ${e.message}');
      rethrow;
    }
  }

  // ── Authenticated: delete a portfolio item ───────────────────────────────
  static Future<void> deletePortfolioItem(int id) async {
    try {
      await ApiService.delete('${ApiConfig.portfolio}/$id');
    } on DioException catch (e) {
      print('PhotographerService.deletePortfolioItem error: ${e.message}');
      rethrow;
    }
  }

  // ── Authenticated: get own portfolio (uses dashboard endpoint) ───────────
  static Future<List<dynamic>> getOwnPortfolio() async {
    try {
      final data = await getDashboard();
      return data['portfolio_analysis'] as List? ?? [];
    } catch (_) {
      return [];
    }
  }
}
// lib/services/message_service.dart

import 'api_service.dart';
import '../config/api_config.dart';


class MessageService {
  static Future<Map<String, dynamic>> getConversations() async {
    final res = await ApiService.get(ApiConfig.conversations);
    return res.data;
  }

  static Future<dynamic> getConversation(int userId) async {
    final res = await ApiService.get('${ApiConfig.messages}/$userId');
    return res.data;
  }

  static Future<Map<String, dynamic>> send(int receiverId, String message) async {
    final res = await ApiService.post(ApiConfig.messages,
        data: {'receiver_id': receiverId, 'message': message});
    return res.data;
  }

  static Future<Map<String, dynamic>> getUnreadCount() async {
    final res = await ApiService.get(ApiConfig.unreadCount);
    return res.data;
  }

  static Future<void> markAsRead(int id) async {
    await ApiService.patch('${ApiConfig.messages}/$id/read');
  }

  static Future<void> deleteMessage(int id) async {
    await ApiService.delete('${ApiConfig.messages}/$id');
  }
}
// lib/services/auth_service.dart

//import 'package:dio/dio.dart';
import 'api_service.dart';
import '../config/api_config.dart';


class AuthService {
  static Future<Map<String, dynamic>> login(String email, String password) async {
    final res = await ApiService.post(ApiConfig.login,
        data: {'email': email, 'password': password});
    return res.data;
  }

  static Future<Map<String, dynamic>> register(Map<String, dynamic> data) async {
    final res = await ApiService.post(ApiConfig.register, data: data);
    return res.data;
  }

  static Future<void> logout() async {
    await ApiService.post(ApiConfig.logout);
  }

  static Future<Map<String, dynamic>> getUser() async {
    final res = await ApiService.get(ApiConfig.user);
    return res.data;
  }
}
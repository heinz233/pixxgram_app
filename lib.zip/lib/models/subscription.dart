class Subscription {
  final int id;
  final int photographerId;
  final String plan;
  final double amount;
  final String status;
  final String? paymentMethod;
  final String? startsAt;
  final String? endsAt;
 
  Subscription({
    required this.id,
    required this.photographerId,
    required this.plan,
    required this.amount,
    required this.status,
    this.paymentMethod,
    this.startsAt,
    this.endsAt,
  });
 
  bool get isActive => status == 'active';
 
  factory Subscription.fromJson(Map<String, dynamic> j) => Subscription(
    id:             j['id'],
    photographerId: j['photographer_id'],
    plan:           j['plan'] ?? 'monthly',
    amount:         double.tryParse(j['amount'].toString()) ?? 0,
    status:         j['status'] ?? 'pending',
    paymentMethod:  j['payment_method'],
    startsAt:       j['starts_at'],
    endsAt:         j['ends_at'],
  );
}
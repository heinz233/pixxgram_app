// lib/models/user.dart

class User {
  final int    id;
  final String name;
  final String email;
  final String? phone;
  final int    roleId;
  final String? userImage;
  final bool   isActive;
  final String? status;
  final String? createdAt;

  const User({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    required this.roleId,
    this.userImage,
    required this.isActive,
    this.status,
    this.createdAt,
  });

  // ── Role helpers ─────────────────────────────────────────────────────────
  bool get isAdmin        => roleId == 1;
  bool get isPhotographer => roleId == 2;
  bool get isClient       => roleId == 3;

  String get roleName {
    switch (roleId) {
      case 1:  return 'Admin';
      case 2:  return 'Photographer';
      default: return 'Client';
    }
  }

  // ── Name helpers ─────────────────────────────────────────────────────────
  String get initials {
    final parts = name.trim().split(' ');
    if (parts.length == 1) return parts[0].substring(0, 1).toUpperCase();
    return '${parts[0][0]}${parts[parts.length - 1][0]}'.toUpperCase();
  }

  String get firstName => name.trim().split(' ').first;

  // ── Image URL helper (resolves relative storage paths) ───────────────────
  String? get imageUrl {
    if (userImage == null || userImage!.isEmpty) return null;
    if (userImage!.startsWith('http')) return userImage;
    if (userImage!.startsWith('/storage/')) {
      return 'http://192.168.3.107:8000$userImage';
    }
    return 'http://192.168.3.107:8000/storage/$userImage';
  }

  bool get isSuspended => status == 'suspended' || status == 'banned';

  // ── Serialisation ────────────────────────────────────────────────────────
  factory User.fromJson(Map<String, dynamic> j) => User(
        id:        j['id'] is String ? int.parse(j['id']) : (j['id'] ?? 0),
        name:      j['name'] ?? '',
        email:     j['email'] ?? '',
        phone:     j['phoneNumber'] ?? j['phone'],
        roleId:    j['role_id'] is String
                      ? int.parse(j['role_id'])
                      : (j['role_id'] ?? 3),
        userImage: j['user_image'],
        isActive:  j['is_active'] == true || j['is_active'] == 1,
        status:    j['status'],
        createdAt: j['created_at'],
      );

  Map<String, dynamic> toJson() => {
        'id':         id,
        'name':       name,
        'email':      email,
        'phoneNumber':phone,
        'role_id':    roleId,
        'user_image': userImage,
        'is_active':  isActive,
        'status':     status,
        'created_at': createdAt,
      };

  User copyWith({
    int?    id,
    String? name,
    String? email,
    String? phone,
    int?    roleId,
    String? userImage,
    bool?   isActive,
    String? status,
    String? createdAt,
  }) =>
      User(
        id:        id        ?? this.id,
        name:      name      ?? this.name,
        email:     email     ?? this.email,
        phone:     phone     ?? this.phone,
        roleId:    roleId    ?? this.roleId,
        userImage: userImage ?? this.userImage,
        isActive:  isActive  ?? this.isActive,
        status:    status    ?? this.status,
        createdAt: createdAt ?? this.createdAt,
      );

  @override
  bool operator ==(Object other) =>
      other is User && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
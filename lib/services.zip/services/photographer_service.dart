// lib/services/photographer_service.dart

import 'package:dio/dio.dart';
import 'api_service.dart';
import '../config/api_config.dart';

class PhotographerService {
  static Future<Map<String, dynamic>> getAll({Map<String, dynamic>? filters}) async {
    final res = await ApiService.get(ApiConfig.photographers, params: filters);
    return res.data;
  }

  static Future<Map<String, dynamic>> getById(int id) async {
    final res = await ApiService.get('${ApiConfig.photographers}/$id');
    return res.data;
  }

  static Future<Map<String, dynamic>> getDashboard() async {
    final res = await ApiService.get(ApiConfig.dashboard);
    return res.data;
  }

  static Future<Map<String, dynamic>> updateProfile(FormData data) async {
    final res = await ApiService.upload(ApiConfig.profile, data);
    return res.data;
  }

  static Future<Map<String, dynamic>> uploadPortfolio(FormData data) async {
    final res = await ApiService.upload(ApiConfig.portfolio, data);
    return res.data;
  }

  static Future<void> deletePortfolioItem(int id) async {
    await ApiService.delete('${ApiConfig.portfolio}/$id');
  }
}
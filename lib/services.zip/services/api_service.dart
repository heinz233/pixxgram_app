// lib/services/api_service.dart

import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';

class ApiService {
  static final Dio _dio = Dio(
    BaseOptions(
      baseUrl: ApiConfig.baseUrl,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
      headers: {
        'Content-Type': 'application/json',
        'Accept':       'application/json',
      },
    ),
  );

  static void init() {
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final prefs = await SharedPreferences.getInstance();
          final token = prefs.getString('auth_token');
          if (token != null) {
            options.headers['Authorization'] = 'Bearer $token';
          }

          // ── Debug: print every outgoing request ──
          print('┌── API REQUEST ──────────────────────────');
          print('│ ${options.method} ${options.baseUrl}${options.path}');
          print('│ Headers: ${options.headers}');
          if (options.data != null) print('│ Body: ${options.data}');
          print('└─────────────────────────────────────────');

          return handler.next(options);
        },

        onResponse: (response, handler) {
          // ── Debug: print every response ──
          print('┌── API RESPONSE ─────────────────────────');
          print('│ Status: ${response.statusCode}');
          print('│ URL: ${response.requestOptions.path}');
          print('│ Data: ${response.data.toString().substring(0,
              response.data.toString().length > 300 ? 300 : response.data.toString().length)}...');
          print('└─────────────────────────────────────────');
          return handler.next(response);
        },

        onError: (error, handler) async {
          // ── Debug: print every error ──
          print('┌── API ERROR ────────────────────────────');
          print('│ URL: ${error.requestOptions.path}');
          print('│ Status: ${error.response?.statusCode}');
          print('│ Message: ${error.message}');
          print('│ Response: ${error.response?.data}');
          print('└─────────────────────────────────────────');

          if (error.response?.statusCode == 401) {
            final prefs = await SharedPreferences.getInstance();
            await prefs.remove('auth_token');
            await prefs.remove('user_data');
          }
          return handler.next(error);
        },
      ),
    );
  }

  static Future<Response> get(String endpoint,
      {Map<String, dynamic>? params}) =>
      _dio.get(endpoint, queryParameters: params);

  static Future<Response> post(String endpoint, {dynamic data}) =>
      _dio.post(endpoint, data: data);

  static Future<Response> put(String endpoint, {dynamic data}) =>
      _dio.put(endpoint, data: data);

  static Future<Response> patch(String endpoint, {dynamic data}) =>
      _dio.patch(endpoint, data: data);

  static Future<Response> delete(String endpoint) =>
      _dio.delete(endpoint);

  static Future<Response> upload(String endpoint, FormData formData) =>
      _dio.post(
        endpoint,
        data: formData,
        options: Options(
          headers: {'Content-Type': 'multipart/form-data'},
        ),
      );
}
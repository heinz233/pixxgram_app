// lib/services/subscription_service.dart
import 'api_service.dart';
import '../config/api_config.dart';

class SubscriptionService {
  static Future<Map<String, dynamic>> getPlans() async {
    final res = await ApiService.get(ApiConfig.subscriptionPlans);
    return res.data;
  }

  static Future<Map<String, dynamic>> getCurrent() async {
    final res = await ApiService.get(ApiConfig.subscriptionCurrent);
    return res.data;
  }

  static Future<Map<String, dynamic>> getHistory() async {
    final res = await ApiService.get(ApiConfig.subscriptionHistory);
    return res.data;
  }

  static Future<Map<String, dynamic>> subscribe({
    required String plan,
    required String paymentMethod,
    String? phone,
  }) async {
    final res = await ApiService.post(ApiConfig.subscriptionSubscribe, data: {
      'plan':           plan,
      'payment_method': paymentMethod,
      if (phone != null) 'phone': phone,
    });
    return res.data;
  }

  static Future<Map<String, dynamic>> cancel(int id) async {
    final res = await ApiService.post('${ApiConfig.subscriptions}/$id/cancel');
    return res.data;
  }

  static Future<Map<String, dynamic>> pollMpesaStatus(String checkoutRequestId) async {
    final res = await ApiService.get(
        '${ApiConfig.subscriptions}/mpesa/status/$checkoutRequestId');
    return res.data;
  }
}

// lib/services/payment_service.dart
class PaymentService {
  static Future<Map<String, dynamic>> initiateMpesa({
    required String phone,
    required double amount,
    required String reference,
  }) async {
    final res = await ApiService.post('payments/initiate', data: {
      'phone':     phone,
      'amount':    amount,
      'reference': reference,
    });
    return res.data;
  }
}
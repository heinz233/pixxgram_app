// lib/services/booking_service.dart
import 'api_service.dart';
import '../config/api_config.dart';


class BookingService {
  static Future<Map<String, dynamic>> getAll() async {
    final res = await ApiService.get(ApiConfig.bookings);
    return res.data;
  }

  static Future<Map<String, dynamic>> create({
    required int photographerId,
    required String bookingDate,
    String? notes,
  }) async {
    final res = await ApiService.post(ApiConfig.bookings, data: {
      'photographer_id': photographerId,
      'booking_date':    bookingDate,
      if (notes != null) 'notes': notes,
    });
    return res.data;
  }

  static Future<Map<String, dynamic>> updateStatus(int id, String status) async {
    final res = await ApiService.patch('${ApiConfig.bookings}/$id/status',
        data: {'status': status});
    return res.data;
  }
}
class User {
  final int id;
  final String name;
  final String email;
  final String? phone;
  final int roleId;
  final String? userImage;
  final bool isActive;
  final String? status;
 
  User({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    required this.roleId,
    this.userImage,
    required this.isActive,
    this.status,
  });
 
  bool get isAdmin        => roleId == 1;
  bool get isPhotographer => roleId == 2;
  bool get isClient       => roleId == 3;
 
  factory User.fromJson(Map<String, dynamic> j) => User(
    id:        j['id'] is String ? int.parse(j['id']) : j['id'],
    name:      j['name'] ?? '',
    email:     j['email'] ?? '',
    phone:     j['phoneNumber'],
    roleId:    j['role_id'] ?? 3,
    userImage: j['user_image'],
    isActive:  j['is_active'] == true || j['is_active'] == 1,
    status:    j['status'],
  );
}
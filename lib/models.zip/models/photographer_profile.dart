class PhotographerProfile {
  final int id;
  final int userId;
  final String? bio;
  final String? location;
  final String? gender;
  final int? age;
  final String? speciality;
  final double? hourlyRate;
  final String? profilePhoto;
  final double? averageRating;
  final int? totalRatings;
  final String? subscriptionStatus;
  final String? subscriptionEndDate;
  final bool isVerified;
  final Map<String, dynamic>? serviceRates;
 
  PhotographerProfile({
    required this.id,
    required this.userId,
    this.bio,
    this.location,
    this.gender,
    this.age,
    this.speciality,
    this.hourlyRate,
    this.profilePhoto,
    this.averageRating,
    this.totalRatings,
    this.subscriptionStatus,
    this.subscriptionEndDate,
    this.isVerified = false,
    this.serviceRates,
  });
 
  bool get isSubscriptionActive => subscriptionStatus == 'active';
 
  factory PhotographerProfile.fromJson(Map<String, dynamic> j) => PhotographerProfile(
    id:                  j['id'] ?? 0,
    userId:              j['user_id'] ?? 0,
    bio:                 j['bio'],
    location:            j['location'],
    gender:              j['gender'],
    age:                 j['age'],
    speciality:          j['speciality'],
    hourlyRate:          j['hourly_rate'] != null ? double.tryParse(j['hourly_rate'].toString()) : null,
    profilePhoto:        j['profile_photo'],
    averageRating:       j['average_rating'] != null ? double.tryParse(j['average_rating'].toString()) : null,
    totalRatings:        j['total_ratings'],
    subscriptionStatus:  j['subscription_status'],
    subscriptionEndDate: j['subscription_end_date'],
    isVerified:          j['is_verified'] == true || j['is_verified'] == 1,
    serviceRates:        j['service_rates'],
  );
}
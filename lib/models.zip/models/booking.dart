import 'user.dart';



class Booking {
  final int id;
  final int clientId;
  final int photographerId;
  final String bookingDate;
  final String? notes;
  final String status;
  final double? amount;
  final String? paymentStatus;
  final User? client;
  final User? photographer;
 
  Booking({
    required this.id,
    required this.clientId,
    required this.photographerId,
    required this.bookingDate,
    this.notes,
    required this.status,
    this.amount,
    this.paymentStatus,
    this.client,
    this.photographer,
  });
 
  factory Booking.fromJson(Map<String, dynamic> j) => Booking(
    id:             j['id'],
    clientId:       j['client_id'],
    photographerId: j['photographer_id'],
    bookingDate:    j['booking_date'] ?? '',
    notes:          j['notes'],
    status:         j['status'] ?? 'pending',
    amount:         j['amount'] != null ? double.tryParse(j['amount'].toString()) : null,
    paymentStatus:  j['payment_status'],
    client:         j['client'] != null ? User.fromJson(j['client']) : null,
    photographer:   j['photographer'] != null ? User.fromJson(j['photographer']) : null,
  );
}